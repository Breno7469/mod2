let drawing = false;

function setup() {
  createCanvas(600, 600);
  background(255);
  strokeWeight(4);
}

function draw() {
  if (drawing) {
    stroke(0);
    line(mouseX, mouseY, pmouseX, pmouseY);
  }
}

function mousePressed() {
  drawing = true;
}

function mouseReleased() {
  drawing = false;
}
